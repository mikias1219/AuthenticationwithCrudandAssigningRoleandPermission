{{-- Comment out or remove the @vite line --}}
{{-- @vite(['resources/js/app.js', "resources/js/Pages/{$page['component']}.vue"]) --}}

{{-- If you need a simple API response page, use: --}}
<!DOCTYPE html>
<html>
<head>
    <title>API Backend</title>
</head>
<body>
    <h1>Laravel API Backend Running</h1>
    <p>Vue frontend should be accessed separately on port 5173</p>
</body>
</html>