<?php

use App\Models\Role;
use App\Models\Permission;
use Illuminate\Support\Facades\DB;

require __DIR__ . '/vendor/autoload.php';
$app = require __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

echo "Checking tables for guard_name column...\n";

$roleColumns = DB::getSchemaBuilder()->getColumnListing('roles');
echo "Roles table columns: " . implode(', ', $roleColumns) . "\n";

$permissionColumns = DB::getSchemaBuilder()->getColumnListing('permissions');
echo "Permissions table columns: " . implode(', ', $permissionColumns) . "\n";

echo "\nChecking first role and permission:\n";
$role = Role::first();
if ($role) {
    echo "Role: " . $role->name . "\n";
    if (isset($role->guard_name)) {
        echo "Role guard_name: " . $role->guard_name . "\n";
    } else {
        echo "Role model does not have guard_name attribute accessible directly (might be hidden or not loaded if not in fillable? no, should be in attributes)\n";
        print_r($role->toArray());
    }
} else {
    echo "No roles found.\n";
}

$permission = Permission::first();
if ($permission) {
    echo "Permission: " . $permission->name . "\n";
    if (isset($permission->guard_name)) {
        echo "Permission guard_name: " . $permission->guard_name . "\n";
    } else {
        print_r($permission->toArray());
    }
} else {
    echo "No permissions found.\n";
}

// Check if any permission has a different guard than the role
if ($role && $permission) {
     // Raw query to see guard_names
     $roleRaw = DB::table('roles')->where('id', $role->id)->first();
     $permRaw = DB::table('permissions')->where('id', $permission->id)->first();

     echo "\nRaw DB Data:\n";
     echo "Role guard: " . ($roleRaw->guard_name ?? 'N/A') . "\n";
     echo "Permission guard: " . ($permRaw->guard_name ?? 'N/A') . "\n";
}
