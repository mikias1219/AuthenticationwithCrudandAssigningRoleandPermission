



<!DOCTYPE html>
<html>
<head>
    <title>API Backend</title>
</head>
<body>
    <h1>Laravel API Backend Running</h1>
    <p>Vue frontend should be accessed separately on port 5173</p>
</body>
</html><?php /**PATH D:\Vuefrontend\backend\backend\resources\views/app.blade.php ENDPATH**/ ?>