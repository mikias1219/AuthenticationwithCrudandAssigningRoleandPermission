<?php

use App\Models\User;
use Illuminate\Support\Facades\DB;

require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$email = 'admin@king.com';
$user = User::where('email', $email)->with('role')->first();

if (!$user) {
    echo "User $email not found.\n";
    exit(1);
}

echo "User ID: " . $user->id . "\n";
echo "Name: " . $user->name . "\n";
echo "Role ID: " . $user->role_id . "\n";

if ($user->role) {
    echo "Role Name: '" . $user->role->name . "'\n"; // Wrapped in quotes to check whitespace
    echo "Is Admin? " . ($user->role->name === 'Admin' ? 'YES' : 'NO') . "\n";
} else {
    echo "Role relationship is NULL.\n";
    // Check raw DB
    $userRaw = DB::table('users')->where('email', $email)->first();
    echo "Raw Role ID: " . $userRaw->role_id . "\n";
    $roleRaw = DB::table('roles')->where('id', $userRaw->role_id)->first();
    echo "Raw Role Name: " . ($roleRaw ? "'".$roleRaw->name."'" : "NULL") . "\n";
}
