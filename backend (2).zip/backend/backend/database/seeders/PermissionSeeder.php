<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Permission;

class PermissionSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [
            ['name' => 'view_users'],
            ['name' => 'create_users'],
            ['name' => 'edit_users'],
            ['name' => 'delete_users'],
            ['name' => 'view_roles'],
            ['name' => 'manage_roles'],
            ['name' => 'view_permissions'],
            ['name' => 'manage_permissions'],
        ];

        foreach ($permissions as $permission) {
            Permission::create($permission);
        }
    }
}