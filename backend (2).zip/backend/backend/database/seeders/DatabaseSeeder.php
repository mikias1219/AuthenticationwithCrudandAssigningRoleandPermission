<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Role;
use App\Models\Permission;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        echo "=== Starting Database Seeding ===\n";
        
        // 1. Create Roles
        echo "Creating roles...\n";
        $adminRole = Role::firstOrCreate(['name' => 'Admin']);
        $managerRole = Role::firstOrCreate(['name' => 'Manager']);
        $userRole = Role::firstOrCreate(['name' => 'User']);
        
        echo "Admin Role ID: " . $adminRole->id . "\n";
        echo "Manager Role ID: " . $managerRole->id . "\n";
        echo "User Role ID: " . $userRole->id . "\n";
        echo "✓ Created 3 roles\n";
        
       // In your DatabaseSeeder.php, update the permissions section:
echo "Creating permissions...\n";
Permission::firstOrCreate(['name' => 'manage_users']);
Permission::firstOrCreate(['name' => 'manage_roles']);  // Add this - for role management
Permission::firstOrCreate(['name' => 'view_content']);
Permission::firstOrCreate(['name' => 'edit_content']);
Permission::firstOrCreate(['name' => 'assign_roles']);
echo "✓ Created 5 permissions\n";

// Update role-permission relationships
echo "Setting up role-permission relationships...\n";
DB::table('role_permissions')->delete(); // Clear existing

// Admin gets all permissions including manage_roles
$adminRole->permissions()->sync([1, 2, 3, 4, 5]);  // All 5 permissions

// Manager gets view and edit ONLY (not manage_roles)
$managerRole->permissions()->sync([3, 4]);  // view_content and edit_content only

// User gets only view
$userRole->permissions()->sync([3]);  // view_content only
        echo "✓ Set up role-permission relationships\n";
        
        // 4. Create Default Users
        echo "Creating default users...\n";
        
        // Admin User
        User::firstOrCreate(
            ['email' => 'admin@example.com'],
            [
                'name' => 'Administrator',
                'password' => Hash::make('admin123'), // Fixed: admin123 not admin1234
                'role_id' => $adminRole->id,
                'email_verified_at' => now(),
            ]
        );
        echo "Created admin user\n";
        
        // Manager User
        User::firstOrCreate(
            ['email' => 'manager@example.com'],
            [
                'name' => 'Manager User',
                'password' => Hash::make('manager123'),
                'role_id' => $managerRole->id,
                'email_verified_at' => now(),
            ]
        );
        echo "Created manager user\n";
        
        // Regular User
        User::firstOrCreate(
            ['email' => 'user@example.com'],
            [
                'name' => 'Regular User',
                'password' => Hash::make('user123'),
                'role_id' => $userRole->id,
                'email_verified_at' => now(),
            ]
        );
        echo "Created regular user\n";
        
        // Test User
        User::firstOrCreate(
            ['email' => 'test@example.com'],
            [
                'name' => 'Test User',
                'password' => Hash::make('password'),
                'role_id' => $userRole->id,
                'email_verified_at' => now(),
            ]
        );
        echo "Created test user\n";
        
        echo "✓ Created 4 users\n";
        
        echo "\n=== Seeding Completed Successfully ===\n";
        echo "Default login credentials:\n";
        echo "1. Admin: admin@example.com / admin123\n";
        echo "2. Manager: manager@example.com / manager123\n";
        echo "3. User: user@example.com / user123\n";
        echo "4. Test: test@example.com / password\n";
        echo "\nRole Permissions:\n";
        echo "- Admin: Can manage users, view/edit content, assign roles\n";
        echo "- Manager: Can view and edit content\n";
        echo "- User: Can only view content\n";
    }
}