<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\Permission;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class SimpleSeeder extends Seeder
{
    public function run(): void
    {
        echo "Creating basic data...\n";
        
        // Create roles
        Role::create(['name' => 'Admin']);
        Role::create(['name' => 'Manager']);
        Role::create(['name' => 'User']);
        
        // Create permissions
        Permission::create(['name' => 'manage_users']);
        Permission::create(['name' => 'view_content']);
        Permission::create(['name' => 'edit_content']);
        Permission::create(['name' => 'assign_roles']);
        
        // Create or update user
        $user = User::firstOrCreate(
            ['email' => 'test@example.com'],
            [
                'name' => 'Test User',
                'password' => Hash::make('password'),
            ]
        );
        
        // Assign role
        $user->role_id = 1; // Admin
        $user->save();
        
        echo "Basic data created.\n";
        echo "Note: Role-Permission relationships not set up.\n";
        echo "Set them up manually in tinker or your app.\n";
    }
}