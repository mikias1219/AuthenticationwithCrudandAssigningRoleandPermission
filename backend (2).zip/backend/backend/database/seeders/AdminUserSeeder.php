<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Role;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        // Make sure Admin role exists
        $adminRole = Role::firstOrCreate(['name' => 'Admin']);
        
        // Create admin user
        User::firstOrCreate(
            ['email' => 'admin@example.com'],
            [
                'name' => 'Administrator',
                'password' => Hash::make('admin123'),
                'role_id' => $adminRole->id,
                'email_verified_at' => now(),
            ]
        );

        // Create manager user
        $managerRole = Role::firstOrCreate(['name' => 'Manager']);
        User::firstOrCreate(
            ['email' => 'manager@example.com'],
            [
                'name' => 'Manager User',
                'password' => Hash::make('manager123'),
                'role_id' => $managerRole->id,
                'email_verified_at' => now(),
            ]
        );

        // Create regular user
        $userRole = Role::firstOrCreate(['name' => 'User']);
        User::firstOrCreate(
            ['email' => 'user@example.com'],
            [
                'name' => 'Regular User',
                'password' => Hash::make('user123'),
                'role_id' => $userRole->id,
                'email_verified_at' => now(),
            ]
        );

        echo "Default users created:\n";
        echo "- admin@example.com / admin123 (Admin role)\n";
        echo "- manager@example.com / manager123 (Manager role)\n";
        echo "- user@example.com / user123 (User role)\n";
    }
}