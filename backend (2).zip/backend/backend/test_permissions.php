<?php

use App\Models\Role;
use App\Models\Permission;
use Illuminate\Http\Request;
use App\Http\Controllers\API\RoleController;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

require __DIR__ . '/vendor/autoload.php';
$app = require __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

echo "Starting Permission Fix Verification...\n";

try {
    // 1. Setup Test Data
    echo "1. Setting up test data...\n";
    $role = Role::firstOrCreate(['name' => 'API Test Role']);
    $perm1 = Permission::firstOrCreate(['name' => 'api_test_permission_1']);
    $perm2 = Permission::firstOrCreate(['name' => 'api_test_permission_2']);

    echo "   Role ID: " . $role->id . "\n";
    echo "   Permission IDs: " . $perm1->id . ", " . $perm2->id . "\n";

    // 2. Test syncPermissions with IDs (Simulating Frontend Request)
    echo "\n2. Testing syncPermissions with IDs...\n";

    $request = Request::create('/api/roles/sync-permissions', 'POST', [
        'role_id' => $role->id,
        'permissions' => [$perm1->id, $perm2->id]
    ]);

    $controller = new RoleController();
    $response = $controller->syncPermissions($request);

    $content = json_decode($response->getContent(), true);

    if ($response->status() === 200 && $content['success']) {
        echo "   [SUCCESS] Response Successful.\n";

        // Verify DB
        $role->refresh();
        $attachedIds = $role->permissions->pluck('id')->toArray();
        if (in_array($perm1->id, $attachedIds) && in_array($perm2->id, $attachedIds)) {
            echo "   [SUCCESS] Permissions attached in DB.\n";
        } else {
             echo "   [FAILURE] Database check failed. Attached: " . implode(',', $attachedIds) . "\n";
        }

    } else {
        echo "   [FAILURE] Response Failed: " . $response->status() . "\n";
        print_r($content);
    }

    // 3. Test detachPermissions with IDs
    echo "\n3. Testing detachPermissions with IDs...\n";

    $requestDetach = Request::create('/api/roles/detach-permissions', 'POST', [
        'role_id' => $role->id,
        'permissions' => [$perm1->id]
    ]);

    $responseDetach = $controller->detachPermissions($requestDetach);
    $contentDetach = json_decode($responseDetach->getContent(), true);

    if ($responseDetach->status() === 200 && $contentDetach['success']) {
        echo "   [SUCCESS] Detach Response Successful.\n";

        $role->refresh();
        $attachedIds = $role->permissions->pluck('id')->toArray();
        if (!in_array($perm1->id, $attachedIds) && in_array($perm2->id, $attachedIds)) {
             echo "   [SUCCESS] Permission 1 detached, Permission 2 remains.\n";
        } else {
             echo "   [FAILURE] Database check failed after detach. Attached: " . implode(',', $attachedIds) . "\n";
        }

    } else {
         echo "   [FAILURE] Detach Response Failed.\n";
         print_r($contentDetach);
    }


} catch (\Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString();
}
