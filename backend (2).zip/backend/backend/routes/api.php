<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\UserController;
use App\Http\Controllers\API\RoleController;
use App\Http\Controllers\API\PermissionController;
use App\Http\Controllers\API\DashboardController;
use App\Http\Controllers\API\AccountController;
use App\Http\Controllers\API\RoleUserController;

/*
|--------------------------------------------------------------------------
| Public Routes (No Auth Required)
|--------------------------------------------------------------------------
*/
Route::post('/login', [AuthController::class, 'login']);
Route::post('/register', [AuthController::class, 'register']);

Route::get('/test', function () {
    return response()->json([
        'message' => 'API working!',
        'timestamp' => now()
    ]);
});

/*
|--------------------------------------------------------------------------
| Protected Routes (Sanctum Token Required)
|--------------------------------------------------------------------------
*/
Route::middleware('auth:sanctum')->group(function () {

    // Auth routes
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/user', [AuthController::class, 'user']);

    // Dashboard
    Route::get('/dashboard-stats', [DashboardController::class, 'stats']);

    /*
    |--------------------------------------------------------------------------
    | Account Routes (User's own account)
    |--------------------------------------------------------------------------
    */
    Route::get('/account', [AccountController::class, 'show']);
    Route::put('/account', [AccountController::class, 'update']);

    /*
    |--------------------------------------------------------------------------
    | User Management
    |--------------------------------------------------------------------------
    */
    // All authenticated users can view users
    Route::get('/users', [UserController::class, 'index']);
    Route::get('/users/{id}', [UserController::class, 'show']);

    // Only users with manage_users permission can modify users
    // NOTE: The middleware name should match what's in Kernel.php
    Route::middleware('check.permission:manage_users')->group(function () {
        Route::post('/users', [UserController::class, 'store']);
        Route::put('/users/{id}', [UserController::class, 'update']);
        Route::delete('/users/{id}', [UserController::class, 'destroy']);
    });

    /*
    |--------------------------------------------------------------------------
    | Role Management
    |--------------------------------------------------------------------------
    */
    // All authenticated users can view roles
    Route::get('/roles', [RoleController::class, 'index']);
    Route::get('/roles/{id}', [RoleController::class, 'show']);

    // Only users with manage_roles permission can modify roles
    Route::middleware('check.permission:manage_roles')->group(function () {
        Route::post('/roles', [RoleController::class, 'store']);
        Route::put('/roles/{id}', [RoleController::class, 'update']);
        Route::delete('/roles/{id}', [RoleController::class, 'destroy']);
        Route::post('/roles/assign-permission', [RoleController::class, 'addPermission']);
        Route::post('/roles/remove-permission', [RoleController::class, 'removePermission']);
        Route::post('/roles/assign-user', [RoleController::class, 'assignUser']);

        // Fix for missing routes requested by frontend
        Route::post('/role/permissions', [RoleController::class, 'syncPermissions']);
        Route::post('/role/permission', [RoleController::class, 'syncPermissions']);
        Route::delete('/role/permissions', [RoleController::class, 'detachPermissions']);
        Route::delete('/role/permission', [RoleController::class, 'detachPermissions']);
    });

    /*
    |--------------------------------------------------------------------------
    | Role-User Assignment Routes
    |--------------------------------------------------------------------------
    */
    Route::middleware('check.permission:assign_roles')->group(function () {
        Route::post('/role/user', [RoleUserController::class, 'assignUserToRole']);
        Route::delete('/role/user', [RoleUserController::class, 'removeUserFromRole']);
        Route::get('/role/users', [RoleUserController::class, 'getUsersWithRoles']);
        Route::get('/role/{id}/users', [RoleUserController::class, 'getRoleWithUsers']);
    });

    /*
    |--------------------------------------------------------------------------
    | Permission Management
    |--------------------------------------------------------------------------
    */
    Route::get('/permissions', [PermissionController::class, 'index']);
    Route::get('/my-permissions', [PermissionController::class, 'myPermissions']);
    Route::post('/permissions', [PermissionController::class, 'store'])->middleware('check.permission:manage_roles');
});
