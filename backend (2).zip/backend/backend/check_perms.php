<?php

use App\Models\Role;
use App\Models\User;
use App\Models\Permission;
use Illuminate\Support\Facades\DB;

require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$role = Role::where('name', 'Admin')->first();
echo "Admin Role ID: " . $role->id . "\n";

$perms = $role->permissions;
echo "Permissions count: " . $perms->count() . "\n";
foreach($perms as $p) {
    echo " - " . $p->name . "\n";
}

$pUsers = Permission::where('name', 'manage_users')->first();
if (!$pUsers) {
    echo "CRITICAL: 'manage_users' permission does not exist in permissions table!\n";
} else {
    echo "'manage_users' ID: " . $pUsers->id . "\n";

    $exists = DB::table('role_permissions')
        ->where('role_id', $role->id)
        ->where('permission_id', $pUsers->id)
        ->exists();
    echo "Admin has 'manage_users'? " . ($exists ? "YES" : "NO") . "\n";
}
