<?php

use App\Models\User;
use App\Models\Role;
use Illuminate\Support\Facades\Log;

require __DIR__ . '/vendor/autoload.php';
$app = require __DIR__ . '/bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

try {
    echo "Fetching users...\n";
    $user = User::first();
    if (!$user) {
        // Create a user if none exists
        $user = User::create([
            'name' => 'Test User',
            'email' => 'test@example.com',
            'password' => bcrypt('password'),
        ]);
        echo "Created test user: " . $user->id . "\n";
    } else {
        echo "Found user: " . $user->id . "\n";
    }

    echo "Fetching roles...\n";
    $role = Role::first();
    if (!$role) {
        $role = Role::create(['name' => 'Test Role']);
        echo "Created test role: " . $role->id . "\n";
    } else {
        echo "Found role: " . $role->id . "\n";
    }

    echo "Attempting assignment...\n";
    $user->role_id = $role->id;
    $user->save();

    echo "Assignment successful!\n";
    echo "User Role ID: " . $user->role_id . "\n";

    // Also test the relationship
    $user->refresh();
    echo "User Role Relation: " . ($user->role ? $user->role->name : 'None') . "\n";

} catch (\Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString();
}
