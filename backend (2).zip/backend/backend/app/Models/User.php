<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role_id',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    // Relationship with Role
    public function role()
    {
        return $this->belongsTo(Role::class);
    }

    // Add this method for compatibility with middleware
    public function hasPermission($permissionName)
    {
        return $this->hasPermissionTo($permissionName);
    }

    // Rename this method to avoid conflict with Laravel's can() method
    public function hasPermissionTo($permissionName)
    {
        if (!$this->role) {
            return false;
        }

        return $this->role->permissions()
            ->where('name', $permissionName)
            ->exists();
    }

    // You can also add an alias for convenience
    public function canDo($permissionName)
    {
        return $this->hasPermissionTo($permissionName);
    }

    // Check if user has a specific role
    public function hasRole($roleName)
    {
        if (!$this->role) {
            return false;
        }

        return $this->role->name === $roleName;
    }

    // Convenience methods for role checking
    public function isAdmin()
    {
        return $this->hasRole('Admin');
    }

    public function isManager()
    {
        return $this->hasRole('Manager');
    }

    public function isUser()
    {
        return $this->hasRole('User');
    }
}