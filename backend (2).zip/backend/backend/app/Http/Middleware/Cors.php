<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\UserController;
use App\Http\Controllers\API\RoleController;
use App\Http\Controllers\API\PermissionController;
use App\Http\Controllers\API\AuthController;

// Public routes (no authentication required)
Route::middleware(['cors'])->group(function () {
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/register', [AuthController::class, 'register']);
    Route::get('/test', function () {
        return response()->json([
            'message' => 'API working!',
            'timestamp' => now()
        ]);
    });
});

// Protected routes (authentication required)
Route::middleware(['cors', 'auth:sanctum'])->group(function () {
    // Authentication
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/user', [AuthController::class, 'user']);
    
    // Dashboard
    Route::get('/dashboard-stats', [App\Http\Controllers\API\DashboardController::class, 'stats']);
    
    // Users
    Route::apiResource('users', UserController::class);
    
    // Roles
    Route::get('/roles', [RoleController::class, 'index']);       
    Route::post('/role/permission', [RoleController::class, 'addPermission']); 
    Route::post('/role/user', [RoleController::class, 'assignUser']);          
    
    // Permissions
    Route::get('/permissions', [PermissionController::class, 'index']);
    Route::post('/permissions', [PermissionController::class, 'store']);
});