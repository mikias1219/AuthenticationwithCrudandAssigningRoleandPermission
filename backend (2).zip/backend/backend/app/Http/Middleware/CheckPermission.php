<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

use Illuminate\Support\Facades\Log;

class CheckPermission
{
    public function handle(Request $request, Closure $next, string $permission): Response
    {
        $user = $request->user();

        if (!$user) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }

        // Debug logging
        Log::info('CheckPermission Middleware:', [
            'user_id' => $user->id,
            'role_loaded' => $user->relationLoaded('role'),
            'role_name' => $user->role ? $user->role->name : 'NULL',
            'permission_requested' => $permission
        ]);

        // Ensure role is loaded
        if (!$user->relationLoaded('role')) {
            $user->load('role');
        }

        // Always allow Admin (trim to be safe)
        if ($user->role && trim($user->role->name) === 'Admin') {
            return $next($request);
        }

        // Check permission
        if ($user->hasPermission($permission)) {
            return $next($request);
        }

        Log::warning('Access Denied in CheckPermission:', [
             'user_id' => $user->id,
             'required' => $permission,
             'actual_role' => $user->role ? $user->role->name : 'None'
        ]);

        return response()->json([
            'error' => 'Access Denied',
            'message' => 'You need the ' . $permission . ' permission to view this page.',
            'user_role' => $user->role ? $user->role->name : 'No role'
        ], 403);
    }
}
