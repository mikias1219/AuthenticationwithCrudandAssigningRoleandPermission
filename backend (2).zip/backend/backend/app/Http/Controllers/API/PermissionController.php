<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;  // Add this line
use App\Models\Permission;

class PermissionController extends Controller
{
    // Return ALL permissions (for admin management only)
    public function index()
    {
        // Get authenticated user
        $user = Auth::user();
        
        if (!$user) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }
        
        // DEBUG: Log user info
        Log::info('PermissionController - User info:', [  // Fixed: Use Log facade
            'user_id' => $user->id,
            'user_email' => $user->email,
            'user_role' => $user->role ? $user->role->name : 'No role'
        ]);
        
        // IMPORTANT: Allow ALL authenticated users to see permissions
        // This is for the UI to show available permissions
        return Permission::all();
        
        // If you want to restrict to admin only, use this:
        /*
        if ($user->role && $user->role->name === 'Admin') {
            return Permission::all();
        }
        
        return response()->json([
            'message' => 'You do not have permission to view all permissions',
            'permissions' => $user->role ? $user->role->permissions : []
        ], 403);
        */
    }
    
    // Return ONLY the logged-in user's permissions
    public function myPermissions()
    {
        $user = Auth::user();
        
        if (!$user) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }
        
        Log::info('myPermissions - User info:', [  // Fixed: Use Log facade
            'user_id' => $user->id,
            'user_role' => $user->role ? $user->role->name : 'No role'
        ]);
        
        if ($user->role) {
            return response()->json([
                'permissions' => $user->role->permissions,
                'role' => $user->role->name
            ]);
        }
        
        return response()->json(['permissions' => []]);
    }

    public function store(Request $request)
    {
        $user = Auth::user();
        
        // Only admin can create permissions
        if (!$user || !$user->role || $user->role->name !== 'Admin') {
            return response()->json([
                'message' => 'Unauthorized to create permissions',
                'error' => 'Admin role required'
            ], 403);
        }
        
        try {
            $request->validate([
                'name' => 'required|string|max:255|unique:permissions,name'
            ]);
            
            $perm = Permission::create(['name' => $request->name]);
            
            return response()->json([
                'success' => true,
                'message' => 'Permission created successfully',
                'data' => $perm
            ], 201);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create permission',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}