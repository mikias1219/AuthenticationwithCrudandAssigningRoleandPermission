<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Role;
use App\Models\Permission;

class DashboardController extends Controller
{
    public function stats()
    {
        try {
            $users = User::count();
            $roles = Role::count();
            $permissions = Permission::count();
            
            return response()->json([
                'success' => true,
                'users' => $users,
                'roles' => $roles,
                'permissions' => $permissions,
                'message' => 'Dashboard stats retrieved successfully'
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error retrieving dashboard stats',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}