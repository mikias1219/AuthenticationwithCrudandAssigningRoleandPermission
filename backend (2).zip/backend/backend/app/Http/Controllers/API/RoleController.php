<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;  // Add this import
use App\Models\Role;
use App\Models\User;
use App\Models\Permission;
use Illuminate\Support\Facades\Validator;

class RoleController extends Controller
{
    /**
     * Get all roles with their permissions and users
     */
    public function index()
    {
        try {
            $roles = Role::with(['permissions', 'users'])->get();

            return response()->json([
                'success' => true,
                'data' => $roles
            ]);

        } catch (\Exception $e) {
            Log::error('Error fetching roles:', [  // Use Log:: instead of \Log::
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch roles',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // ... rest of your methods ...


    /**
     * Get a specific role by ID
     */
   // Add these methods to your RoleController

/**
 * Show a specific role
 */
public function show($id)
{
    try {
        $role = Role::with(['permissions', 'users'])->find($id);

        if (!$role) {
            return response()->json([
                'success' => false,
                'message' => 'Role not found'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $role
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Failed to fetch role',
            'error' => $e->getMessage()
        ], 500);
    }
}

/**
 * Store/Create a new role
 */
public function store(Request $request)
{
    try {
        $request->validate([
            'name' => 'required|string|max:255|unique:roles,name'
        ]);

        $role = Role::create([
            'name' => $request->name
        ]);

        $role->load(['permissions', 'users']);

        return response()->json([
            'success' => true,
            'message' => 'Role created successfully',
            'data' => $role
        ], 201);

    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Failed to create role',
            'error' => $e->getMessage()
        ], 500);
    }
}

/**
 * Update a role
 */
public function update(Request $request, $id)
{
    try {
        $request->validate([
            'name' => 'required|string|max:255|unique:roles,name,' . $id
        ]);

        $role = Role::find($id);

        if (!$role) {
            return response()->json([
                'success' => false,
                'message' => 'Role not found'
            ], 404);
        }

        $role->update([
            'name' => $request->name
        ]);

        $role->load(['permissions', 'users']);

        return response()->json([
            'success' => true,
            'message' => 'Role updated successfully',
            'data' => $role
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Failed to update role',
            'error' => $e->getMessage()
        ], 500);
    }
}

/**
 * Delete a role
 */
public function destroy($id)
{
    try {
        $role = Role::find($id);

        if (!$role) {
            return response()->json([
                'success' => false,
                'message' => 'Role not found'
            ], 404);
        }

        // Check if role has users assigned
        if ($role->users()->count() > 0) {
            return response()->json([
                'success' => false,
                'message' => 'Cannot delete role that has users assigned'
            ], 400);
        }

        $role->delete();

        return response()->json([
            'success' => true,
            'message' => 'Role deleted successfully'
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Failed to delete role',
            'error' => $e->getMessage()
        ], 500);
    }
}
    /**
     * Add permission to a role
     */
    public function addPermission(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'role_id' => 'required|exists:roles,id',
            'permission_id' => 'required|exists:permissions,id'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $role = Role::findOrFail($request->role_id);
            $permission = Permission::findOrFail($request->permission_id);

            // Check if permission already exists
            if ($role->permissions()->where('permission_id', $request->permission_id)->exists()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Permission already assigned to this role'
                ], 400);
            }

            $role->permissions()->attach($request->permission_id);
            $role->load(['permissions', 'users']);

            return response()->json([
                'success' => true,
                'message' => 'Permission added to role successfully',
                'data' => $role
            ]);

        } catch (\Exception $e) {
            Log::error('Error adding permission to role:', [
                'error' => $e->getMessage(),
                'request' => $request->all()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to add permission to role',
                'error' => $e->getMessage()
            ], 500);
        }
    }

  /**
 * Remove permission from a role
 */
public function removePermission(Request $request)
{
    try {
        $request->validate([
            'role_id' => 'required|exists:roles,id',
            'permission_id' => 'required|exists:permissions,id'
        ]);

        $role = Role::findOrFail($request->role_id);

        // Check if permission exists on role
        if (!$role->permissions()->where('permission_id', $request->permission_id)->exists()) {
            return response()->json([
                'success' => false,
                'message' => 'Permission not assigned to this role'
            ], 400);
        }

        $role->permissions()->detach($request->permission_id);
        $role->load(['permissions', 'users']);

        return response()->json([
            'success' => true,
            'message' => 'Permission removed from role successfully',
            'data' => $role
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Failed to remove permission from role',
            'error' => $e->getMessage()
        ], 500);
    }
}

    /**
     * Sync permissions for a role (Bulk Update)
     */
    /**
     * Sync permissions for a role (Bulk Update)
     */
    public function syncPermissions(Request $request)
    {
        // Normalize Inputs
        if ($request->has('roleId') && !$request->has('role_id')) {
            $request->merge(['role_id' => $request->roleId]);
        }

        $validator = Validator::make($request->all(), [
            'role_id' => 'required|exists:roles,id',
            'permissions' => 'present|array',
            'permissions.*' => 'exists:permissions,id' // Changed from name to id
        ]);

        if ($validator->fails()) {
            file_put_contents(public_path('debug_validation.log'), json_encode([
                'endpoint' => 'syncPermissions',
                'raw_request' => $request->all(),
                'validation_errors' => $validator->errors()
            ], JSON_PRETTY_PRINT));

            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $role = Role::findOrFail($request->role_id);
            $permissions = $request->permissions;

            // Use syncWithoutDetaching to ADD without wiping others
            // Verify if we should sync (overwrite) or syncWithoutDetaching (append/merge).
            // 'syncPermissions' usually implies setting the EXACT state, so 'sync' is more appropriate than 'syncWithoutDetaching'
            // if the intention is "these are the permissions the role should have".
            // However, the original code used `syncWithoutDetaching`. I will stick to the original behavior
            // but simply pass the IDs directly.

            $role->permissions()->syncWithoutDetaching($permissions);

            return response()->json([
                'success' => true,
                'message' => 'Permissions updated successfully',
                'data' => $role->load('permissions')
            ]);

        } catch (\Exception $e) {
            Log::error('Error syncing permissions:', [
                'error' => $e->getMessage(),
                'request' => $request->all()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to sync permissions',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Assign a user to a role
     */
    /**
     * Detach permissions from a role (Granular Remove)
     */
    public function detachPermissions(Request $request)
    {
        // Normalize Inputs
        if ($request->has('roleId') && !$request->has('role_id')) {
            $request->merge(['role_id' => $request->roleId]);
        }

        $validator = Validator::make($request->all(), [
            'role_id' => 'required|exists:roles,id',
            'permissions' => 'present|array',
            'permissions.*' => 'exists:permissions,id' // Changed from name to id
        ]);

        if ($validator->fails()) {
             file_put_contents(public_path('debug_validation.log'), json_encode([
                'endpoint' => 'detachPermissions',
                'raw_request' => $request->all(),
                'validation_errors' => $validator->errors()
            ], JSON_PRETTY_PRINT));

             return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $role = Role::findOrFail($request->role_id);
            $permissions = $request->permissions;
            // $permissionIds = Permission::whereIn('name', $permissions)->pluck('id')->toArray(); // REPLACED

            $role->permissions()->detach($permissions);

            return response()->json([
                'success' => true,
                'message' => 'Permissions detached successfully',
                'data' => $role->load('permissions')
            ]);

        } catch (\Exception $e) {
             Log::error('Error detaching permissions:', [
                'error' => $e->getMessage(),
                'request' => $request->all()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to detach permissions',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Assign a user to a role
     */
    public function assignUser(Request $request)
    {
        // Normalize Inputs
        if ($request->has('roleId') && !$request->has('role_id')) {
            $request->merge(['role_id' => $request->roleId]);
        }
        if ($request->has('userId') && !$request->has('user_id')) {
            $request->merge(['user_id' => $request->userId]);
        }

        $validator = Validator::make($request->all(), [
            'role_id' => 'required|exists:roles,id',
            'user_id' => 'required|exists:users,id'
        ]);

        if ($validator->fails()) {
            Log::error('Role assignment validation failed:', [
                'request' => $request->all(),
                'errors' => $validator->errors()
            ]);
            file_put_contents(public_path('debug_validation.log'), print_r([
                'request' => $request->all(),
                'errors' => $validator->errors()->toArray()
            ], true));

            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $role = Role::findOrFail($request->role_id);
            $user = User::findOrFail($request->user_id);

            // Update user's role
            $user->role_id = $request->role_id;
            $user->save();

            // Load updated relationships
            $role->load(['permissions', 'users']);
            $user->load('role');

            return response()->json([
                'success' => true,
                'message' => 'User assigned to role successfully',
                'data' => [
                    'role' => $role,
                    'user' => $user
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Error assigning user to role:', [
                'error' => $e->getMessage(),
                'request' => $request->all()
            ]);

            file_put_contents(public_path('debug_error.log'), $e->getMessage() . "\n" . $e->getTraceAsString());

            return response()->json([
                'success' => false,
                'message' => 'Failed to assign user to role',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
