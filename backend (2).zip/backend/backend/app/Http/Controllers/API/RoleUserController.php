<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\Role;
use Illuminate\Support\Facades\Log;

class RoleUserController extends Controller
{
    /**
     * Get all users with their roles
     */
    public function getUsersWithRoles()
    {
        try {
            $users = User::with('role')->get();

            return response()->json([
                'success' => true,
                'data' => $users
            ]);

        } catch (\Exception $e) {
            Log::error('Error fetching users with roles:', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch users',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get specific role with its users
     */
    public function getRoleWithUsers($id)
    {
        try {
            $role = Role::with('users')->find($id);

            if (!$role) {
                return response()->json([
                    'success' => false,
                    'message' => 'Role not found'
                ], 404);
            }

            return response()->json([
                'success' => true,
                'data' => $role
            ]);

        } catch (\Exception $e) {
            Log::error('Error fetching role with users:', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch role',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Assign a user to a role
     */
    public function assignUserToRole(Request $request)
    {
        Log::info('Assign user to role request:', $request->all());

        // Normalize Request Inputs (Handle camelCase from frontend)
        if ($request->has('roleId') && !$request->has('role_id')) {
            $request->merge(['role_id' => $request->roleId]);
        }
        if ($request->has('userId') && !$request->has('user_id')) {
            $request->merge(['user_id' => $request->userId]);
        }

        // Validate request
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|exists:users,id',
            'role_id' => 'required|exists:roles,id',
        ]);

        if ($validator->fails()) {
            Log::error('Role assignment validation failed:', [
                'request' => $request->all(),
                'errors' => $validator->errors()
            ]);
            file_put_contents(public_path('debug_validation.log'), json_encode([
                'raw_request' => $request->all(),
                'validation_errors' => $validator->errors()
            ], JSON_PRETTY_PRINT));

            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $user = User::find($request->user_id);
            $role = Role::find($request->role_id);

            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found'
                ], 404);
            }

            if (!$role) {
                return response()->json([
                    'success' => false,
                    'message' => 'Role not found'
                ], 404);
            }

            // Assign role to user
            $user->role_id = $role->id;
            $user->save();

            // Load the role relationship
            $user->load('role');

            Log::info('Role assigned successfully', [
                'user_id' => $user->id,
                'role_id' => $role->id
            ]);

            return response()->json([
                'success' => true,
                'message' => 'User assigned to role successfully',
                'data' => $user
            ]);

        } catch (\Exception $e) {
            Log::error('Error assigning user to role:', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            file_put_contents(public_path('debug_error.log'), $e->getMessage() . "\n" . $e->getTraceAsString());

            return response()->json([
                'success' => false,
                'message' => 'Failed to assign user to role',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Remove a user from a role
     */
    public function removeUserFromRole(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|exists:users,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $user = User::find($request->user_id);

            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found'
                ], 404);
            }

            $user->role_id = null;
            $user->save();

            return response()->json([
                'success' => true,
                'message' => 'User removed from role successfully',
                'data' => $user
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to remove user from role',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
