<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class AccountController extends Controller
{
    /**
     * Get current user's account information.
     */
    public function show()
    {
        try {
            // Get authenticated user ID
            $userId = Auth::id();
            
            if (!$userId) {
                return response()->json([
                    'message' => 'User not authenticated'
                ], 401);
            }
            
            // Get user data directly from database
            $user = DB::table('users')
                ->leftJoin('roles', 'users.role_id', '=', 'roles.id')
                ->select(
                    'users.id',
                    'users.name',
                    'users.email',
                    'users.created_at',
                    'users.updated_at',
                    'roles.id as role_id',
                    'roles.name as role_name'
                )
                ->where('users.id', $userId)
                ->first();
            
            if (!$user) {
                return response()->json([
                    'message' => 'User not found'
                ], 404);
            }
            
            return response()->json([
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role_id ? [
                    'id' => $user->role_id,
                    'name' => $user->role_name
                ] : null,
                'created_at' => $user->created_at,
                'updated_at' => $user->updated_at
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load account',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update user's account information.
     */
    public function update(Request $request)
    {
        try {
            // Get authenticated user ID
            $userId = Auth::id();
            
            if (!$userId) {
                return response()->json([
                    'message' => 'User not authenticated'
                ], 401);
            }
            
            // Get current user data
            $currentUser = DB::table('users')
                ->where('id', $userId)
                ->first();
            
            if (!$currentUser) {
                return response()->json([
                    'message' => 'User not found'
                ], 404);
            }
            
            // Validation rules
            $validator = Validator::make($request->all(), [
                'name' => 'sometimes|required|string|max:255',
                'email' => 'sometimes|required|email|unique:users,email,' . $userId,
                'current_password' => 'required_with:password',
                'password' => 'sometimes|nullable|min:6|confirmed',
            ]);
            
            if ($validator->fails()) {
                return response()->json([
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }
            
            // Prepare update data
            $updateData = [];
            
            // Update name if provided and different
            if ($request->has('name') && $request->name !== $currentUser->name) {
                $updateData['name'] = $request->name;
            }
            
            // Update email if provided and different
            if ($request->has('email') && $request->email !== $currentUser->email) {
                $updateData['email'] = $request->email;
            }
            
            // Update password if provided
            if ($request->filled('password')) {
                // Verify current password
                if (!Hash::check($request->current_password, $currentUser->password)) {
                    return response()->json([
                        'message' => 'Current password is incorrect',
                        'errors' => ['current_password' => ['Current password is incorrect']]
                    ], 422);
                }
                
                $updateData['password'] = Hash::make($request->password);
            }
            
            // Update if there are changes
            if (!empty($updateData)) {
                $updateData['updated_at'] = now();
                
                $updated = DB::table('users')
                    ->where('id', $userId)
                    ->update($updateData);
                
                if (!$updated) {
                    return response()->json([
                        'message' => 'Failed to update account'
                    ], 500);
                }
                
                // Get updated user data
                $updatedUser = DB::table('users')
                    ->leftJoin('roles', 'users.role_id', '=', 'roles.id')
                    ->select(
                        'users.id',
                        'users.name',
                        'users.email',
                        'users.created_at',
                        'users.updated_at',
                        'roles.id as role_id',
                        'roles.name as role_name'
                    )
                    ->where('users.id', $userId)
                    ->first();
                
                return response()->json([
                    'message' => 'Account updated successfully',
                    'user' => [
                        'id' => $updatedUser->id,
                        'name' => $updatedUser->name,
                        'email' => $updatedUser->email,
                        'role' => $updatedUser->role_id ? [
                            'id' => $updatedUser->role_id,
                            'name' => $updatedUser->role_name
                        ] : null,
                        'updated_at' => $updatedUser->updated_at
                    ]
                ]);
            } else {
                return response()->json([
                    'message' => 'No changes detected'
                ], 200);
            }
            
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Update failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Logout user.
     */
    public function logout(Request $request)
    {
        try {
            // If using Sanctum, revoke token
            $user = $request->user();
            if ($user && method_exists($user, 'currentAccessToken')) {
                $user->currentAccessToken()->delete();
            }
            
            // Clear session
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            
            return response()->json([
                'message' => 'Successfully logged out'
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Logout failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}